final class Generator {
	
	final String title = "Unique Value Generator";

	final long generate() {
		return (long) (Math.random()*1000);	
	}
}