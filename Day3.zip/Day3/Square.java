class Square extends Shape {
	
	void draw() {
		System.out.println("Square is drawn!!!!");
	}
}