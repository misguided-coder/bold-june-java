class WrapperDemo {

	public static void main(String[] args) {
		
		int i = 1000;
		Integer it = new Integer(i); //boxing/wrapping int primitive			
		int x = it.intValue(); //unboxing/unwrapping int primitive

		System.out.println(i);
		System.out.println(it);
		System.out.println(x);

		char ch  = 'R';
		Character character = new Character(ch);
		char letter = character.charValue();
		
		System.out.println(ch);
		System.out.println(character);
		System.out.println(letter);
	
		//float amount  = 120000.00F;
		//Float valueObject = new Float(amount);
		Float valueObject = new Float(8000000.00F);
		float rs = valueObject.floatValue();
		
		//System.out.println(amount);
		System.out.println(valueObject);
		System.out.println(rs);
	
		System.out.println("Done!!");
	}
	
}