class StudentDemo {
	public static void main(String[] args) {
		//UC1();
		UC2();
		System.out.println("Done!!");
	}

	static void UC2() {
		Student s1 = new Student(100,"Jaggu",67,89);
		Student s2 = new Student(200,"Pintu",60,90);
		s1.info();
		s2.info();
		
		Student.calculateMarks(s1);
		Student.calculateMarks(s2);
		
	} 

	static void UC1() {

		Student s1 = new Student(100,"Jaggu",67,89);
		Student s2 = new Student(200,"Pintu",60,90);
		Student s3 = new Student(300,"Ram",70,20);
		Student s4 = new Student(400,"Raj",69,60);

		System.out.println(s1.name);
		System.out.println(s1.hindiMarks);
		System.out.println(s1.maxMarks);

		System.out.println(s2.name);
		System.out.println(s2.hindiMarks);
		System.out.println(s2.maxMarks);

		System.out.println(s3.maxMarks);
		System.out.println(s4.maxMarks);

		System.out.println(Student.maxMarks);

		Student.maxMarks = 1000;
		
		System.out.println(s1.maxMarks);

		s4.maxMarks = 200;
		
		System.out.println(s1.maxMarks);
	}
 
}