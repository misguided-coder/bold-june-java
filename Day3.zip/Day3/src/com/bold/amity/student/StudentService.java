package com.bold.amity.student;

import com.bold.amity.transport.TransportService;

class StudentService {

	public static void main(String[] args) {
		//UC1();
		UC2();
	}
	
	static void UC2() {
		TransportService transportService1 = TransportService.createInstance();
		TransportService transportService2 = TransportService.createInstance();
		TransportService transportService3 = TransportService.createInstance();
		
		System.out.println(transportService1);
		System.out.println(transportService2);
		System.out.println(transportService3);
		
		
		System.out.println(transportService1.type);

		transportService1.defineRoute();
	}

	static void UC1() {
		/*TransportService transportService = new TransportService(); //will not compile
		System.out.println(transportService.type);
	
		transportService.defineRoute();*/
	}
}
