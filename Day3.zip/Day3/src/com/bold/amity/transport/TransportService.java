package com.bold.amity.transport;

public class TransportService {
	
	static TransportService transportService = null;
		
	public String type = "Mini Bus";
	private int capacity = 12; //seating capacity
	
	private TransportService() {
		System.out.println("Inside TransportService constructor!!!!!");
	}
		
	public static TransportService createInstance() {
		if(transportService == null) {
			transportService =  new TransportService();
		}
		return transportService;	
	}
	
	
	public void defineRoute() {
		doRouteCalculations();
		System.out.printf("Route no 6 from Noida to Delhi can carry %s pax.%n",this.capacity);
	}
	
	private void doRouteCalculations() {
		System.out.println("Route no 6 will take around 2 hours");
	}	
}
