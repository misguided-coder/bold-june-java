package com.example.object;

public class Car {
	
	public String toString() {
		return "It is all about Luxury cars!!!!";
	}

}
