package com.example.collection;

public class Person {

}
