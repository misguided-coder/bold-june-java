package com.example.collection;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class SetDemo {
	public static void main(String[] args) {
		new SetDemo();
	}

	public SetDemo() {
		UC1();
	}

	void UC1() {

		//Set<String> colors = new HashSet<>();
		Set<String> colors = new TreeSet<>();

		colors.add("Red");
		colors.add("Green");
		colors.add("Blue");
		colors.add("Yellow");
		colors.add("Tomato");
		colors.add("Blue");

		System.out.printf("Size : %s%n", colors.size());
		System.out.printf("Elements : %s%n", colors);
		
		//colors.remove("Tomato");
		colors.clear();

		System.out.printf("Size : %s%n", colors.size());
		System.out.printf("Elements : %s%n", colors);
	
		Iterator<String> iterator = colors.iterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}

	}

}
