package com.example.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class ListDemo {
	public static void main(String[] args) {
		new ListDemo();
	}

	public ListDemo() {
		// UC1();
		// UC2();
		// UC3();
		// UC4();
		// UC5();
		// UC6();
		// UC7();
		//UC8();
		//UC9();
		UC10();
	}
	
	void UC10() {
			List<Integer> list = new LinkedList<>();

			list.add(new Integer(100));
			list.add(new Integer(200));
			list.add(new Integer(300));
			list.add(new Integer(400));

			System.out.printf("Size : %s%n", list.size());
			System.out.printf("List Elements : %s%n", list);
			
			for (Integer val : list) {
				System.out.println(val);
			}
		}

	// adding number elements
	// Java 5 Generic feature
	void UC9() {
		List<Integer> list = new ArrayList<>();

		list.add(new Integer(100));
		list.add(new Integer(200));
		list.add(new Integer(300));
		list.add(new Integer(400));

		System.out.printf("Size : %s%n", list.size());
		System.out.printf("List Elements : %s%n", list);
		
		Integer value = list.get(2);
		System.out.println(value + 12000);
		
		for (Integer val : list) {
			System.out.println(val);
		}
	}

	// sorting elements in array list
	void UC8() {
		List list = new ArrayList();

		list.add(new Integer(600));
		list.add(new Integer(300));
		list.add(new Integer(200));
		list.add(new Integer(200));
		list.add(new Integer(20));
		list.add(new Integer(40));
		list.add(new Integer(800));
		list.add(new Integer(20));

		System.out.printf("Original List : %s%n", list);

		Collections.sort(list);

		System.out.printf("Sorted List : %s%n", list);

		Collections.reverse(list);

		System.out.printf("Reverse List : %s%n", list);

		Collections.shuffle(list);

		System.out.printf("Suffle List : %s%n", list);

		List anotherList = Collections.unmodifiableList(list);

		System.out.printf("Readable List : %s%n", anotherList);

		anotherList.add(5000);
	}

	// iterating over elements using for each
	void UC7() {
		List list = new ArrayList();

		list.add(new Integer(100));
		list.add(new Integer(200));
		list.add(new Integer(300));
		list.add(new Integer(400));
		list.add(new Float(400.00F));
		list.add(new Boolean(true));
		list.add(new String("Yellow"));

		for (Object value : list) {
			System.out.println(value);
		}

	}

	// iterating over elements using Iterator
	void UC6() {
		List list = new ArrayList();

		list.add(new Integer(100));
		list.add(new Integer(200));
		list.add(new Integer(300));
		list.add(new Integer(400));
		list.add(new Float(400.00F));
		list.add(new Boolean(true));
		list.add(new String("Yellow"));

		Iterator itr = list.iterator();
		while (itr.hasNext()) {
			Object value = itr.next();
			System.out.println(value);
		}

	}

	// iterating over elements using for loop
	void UC5() {
		List list = new ArrayList();

		list.add(new Integer(100));
		list.add(new Integer(200));
		list.add(new Integer(300));
		list.add(new Integer(400));
		list.add(new Float(400.00F));
		list.add(new Boolean(true));
		list.add(new String("Yellow"));

		for (int idx = 0; idx < list.size(); idx++) {
			System.out.println(list.get(idx));
		}

	}

	// delete elements
	void UC4() {
		List list = new ArrayList();

		list.add(new Integer(100));
		list.add(new Integer(200));
		list.add(new Integer(300));
		list.add(new Integer(400));
		list.add(new Float(400.00F));
		list.add(new Boolean(true));
		list.add(new String("Yellow"));

		System.out.printf("Size : %s%n", list.size());
		System.out.printf("List Elements : %s%n", list);
		list.remove(2);
		System.out.printf("Size : %s%n", list.size());
		System.out.printf("List Elements : %s%n", list);
	}

	// update elements
	void UC3() {
		List list = new ArrayList();

		list.add(new Integer(100));
		list.add(new Integer(200));
		list.add(new Integer(300));
		list.add(new Integer(400));
		list.add(new Float(400.00F));
		list.add(new Boolean(true));
		list.add(new String("Yellow"));

		System.out.printf("Size : %s%n", list.size());
		System.out.printf("List Elements : %s%n", list);
		list.set(4, "Black");
		System.out.printf("List Elements : %s%n", list);
	}

	// reading elements
	void UC2() {
		List list = new ArrayList();

		list.add(new Integer(100));
		list.add(new Integer(200));
		list.add(new Integer(300));
		list.add(new Integer(400));
		list.add(new Float(400.00F));
		list.add(new Boolean(true));
		list.add(new String("Yellow"));

		System.out.printf("Size : %s%n", list.size());
		System.out.printf("Element Value : %s%n", list.get(4));
	}

	// adding elements
	void UC1() {
		List list = new ArrayList();

		list.add(new Integer(100));
		list.add(new Integer(200));
		list.add(new Integer(300));
		list.add(new Integer(400));
		list.add(new Float(400.00F));
		list.add(new Boolean(true));
		list.add(new String("Yellow"));
		list.add("Red");
		list.add(new Double(120000.00));
		list.add(new Person());
		list.add(new Person());
		list.add(new Float(400.00F));
		list.add(new Person());
		list.add(new Person());
		System.out.printf("Size : %s%n", list.size());
		System.out.printf("List Elements : %s%n", list);

	}

}
