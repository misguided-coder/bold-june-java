package com.example.service.saving;

import com.example.service.Account;

public class SavingAccount extends Account {
	
	void info() {
		System.out.println("Saving Account Info");
		System.out.printf("Account No : %s%n",this.accountNo);
		System.out.printf("Balance : %s%n",this.balance);
		
	}

}
