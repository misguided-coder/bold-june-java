package com.example.service.saving;

public class Main {

	public static void main(String[] args) {
		
		SavingAccount savingAccount = new SavingAccount();
		savingAccount.info();
		
	}
}
