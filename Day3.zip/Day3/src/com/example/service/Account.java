package com.example.service;

public class Account {

	protected int accountNo;
	protected double balance;

	public Account() {
		this.accountNo = 1000;
		this.balance = 450000.00;
	}

	public Account(int accountNo, double balance) {
		this.accountNo = accountNo;
		this.balance = balance;
	}

}
