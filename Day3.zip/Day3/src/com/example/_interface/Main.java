package com.example._interface;

public class Main {
	
	public static void main(String[] args) {
		
		AccountService accountService = new SavingAccountService();
		long accountNo = accountService.open("Pintu", 20000.00);
		accountService.close(accountNo);
	
		accountService = new CurrentAccountService();
		accountNo = accountService.open("Chandu", 50000.00);
		accountService.close(accountNo);
	
	}

}
