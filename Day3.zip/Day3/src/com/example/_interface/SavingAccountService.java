package com.example._interface;

public class SavingAccountService implements AccountService {

	public long open(String name, double initialBalance) {
		System.out.printf("Saving Account opened for Mr %s and Balance is %s%n", name, initialBalance);
		return (long) (Math.random() * 1000);
	}

	public boolean close(long accountNo) {
		System.out.printf("Saving Account No %s is closed%n", accountNo);
		return true;
	}
}
