package com.example._interface;

public interface AccountService {
	public abstract long open(String name,double initialBalance);
	public abstract boolean close(long accountNo);
}
