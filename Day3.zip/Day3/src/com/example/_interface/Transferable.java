package com.example._interface;

public interface Transferable {
	public abstract void transfer(long accountNo,String fromBranch,String toBranch);
}
