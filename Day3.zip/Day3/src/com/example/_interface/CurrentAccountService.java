package com.example._interface;

public class CurrentAccountService implements AccountService, Transferable {

	long odLimit = 5000000L;
	long withdrawLimit = 100000L;
	
	public long open(String name, double initialBalance) {
		System.out.printf("Current Account opened for Mr %s and Balance is %s%n", name, initialBalance);
		return (long) (Math.random() * 5000);
	}

	public boolean close(long accountNo) {
		System.out.printf("Current Account No %s is closed%n", accountNo);
		return true;
	}
	
	public void transfer(long accountNo, String fromBranch, String toBranch) {
		System.out.printf("Current Account No %s is transferred from %s to %s branch%n", accountNo,fromBranch,toBranch);
	}
	
}
