package om.example.io;

import java.io.FileReader;

public class ReadFileDemo1 {
	
	public static void main(String[] args) throws Exception {
		
		//File opened for reading
		FileReader fileReader = new FileReader("C:/bold-java-training/holidays.txt");
		
		char[] buffer = new char[256];
		
		//Start reading
		fileReader.read(buffer);
		
		System.out.println(buffer);
		
		fileReader.close();
	}

}
