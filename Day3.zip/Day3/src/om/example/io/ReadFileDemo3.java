package om.example.io;

import java.io.FileReader;

import com.google.gson.Gson;

public class ReadFileDemo3 {
	
	public static void main(String[] args) throws Exception {
		
		//File opened for reading
		FileReader fileReader = new FileReader("C:/bold-java-training/cars.json");
		char[] buffer = new char[256];
		//Start reading
		fileReader.read(buffer);
		System.out.println(buffer);
		fileReader.close();
		String data = new String(buffer);
		System.out.println(data);
		
		Gson gson = new Gson();
		Car car = gson.fromJson(data, Car.class);
	}

}
