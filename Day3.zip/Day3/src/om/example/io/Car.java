package om.example.io;

public class Car {

	int vin;
	String model;
	
}
