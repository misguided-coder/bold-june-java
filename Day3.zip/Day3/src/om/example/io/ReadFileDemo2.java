package om.example.io;

import java.io.FileReader;

public class ReadFileDemo2 {
	
	public static void main(String[] args) throws Exception {
		
		//File opened for reading
		FileReader fileReader = new FileReader("C:/bold-java-training/cities.txt");
		char[] buffer = new char[256];
		//Start reading
		fileReader.read(buffer);
		System.out.println(buffer);
		fileReader.close();

	
		String data = new String(buffer);
		String[] array = data.split(",");
	
		for(String city : array) {
			System.out.println(city);
			//REST API Call
		}
		
	}

}
