class Student {
	
	int rollNo;
	String name;
	int hindiMarks;
	int englishMarks;
	static int maxMarks = 500; //out of 500
	
	Student() {
	}

	Student(int rollNo,String name,int hindiMarks,int englishMarks) {
		this.rollNo = rollNo;
		this.name = name;
		this.hindiMarks = hindiMarks;
		this.englishMarks = englishMarks;
	}

	void info() {
		System.out.println(this.rollNo);
		System.out.println(this.name);
		System.out.println(this.hindiMarks);
		System.out.println(this.englishMarks);
		System.out.println(this.maxMarks);
		System.out.println("=============================");
	}

	static void calculateMarks(Student student) {
		System.out.println(student.hindiMarks+student.englishMarks);
		System.out.println("=============================");
	}
}