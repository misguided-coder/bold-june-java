abstract class Shape {
	
	String size = "10x8";

	Shape() {
		System.out.println("Inside Shape constructor!!!!");
	}
	
	void info() {
		System.out.println("It is all about shapes!!!!");
	}	

	abstract void draw();
}