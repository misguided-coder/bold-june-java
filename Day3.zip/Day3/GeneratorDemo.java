class GeneratorDemo {
	public static void main(String[] args) {
		
		Generator generator1 = new Generator();
		SequenceGenerator generator2 = new SequenceGenerator();

		System.out.println(generator1.title);
		System.out.println(generator1.generate());

		System.out.println(generator2.title);
		System.out.println(generator2.generate());
	
		//generator.title = "Number Generator"; //will not compile
		System.out.println("Done!!");
	}
}