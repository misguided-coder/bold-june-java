class SequenceGenerator extends Generator {
	
	//can not override coz it is declared final in parent class
	/*long generate() {
		return (long) (Math.random()*20000);	
	}*/
}