class StringDemo {

	public static void main(String[] args) {
		//UC1();
		//UC2();
		//UC3();
		UC4();

		System.out.println("Done!!");
	}

	static void UC4() {

		//String color1 = new String("Yellow");
		//String color2 = new String("Yellow");

		String color1 = "Yellow";
		String color2 = "Yellow";

		System.out.println(color1);
		System.out.println(color1.toString());
		System.out.println(color2);
		System.out.println(color2.toString());

		System.out.println(color1 == color2);

		System.out.println(color1.hashCode());
		System.out.println(color2.hashCode());

	}

	static void UC3() {
		
		//Java 5
		StringBuilder color = new StringBuilder("Yellow");
		color.append(" ");
		color.append(" is ");
		color.append(" nice ");
		color.append(" cool ");
		color.append(" color ");

		System.out.println(color);
	}



	static void UC2() {

		StringBuffer color = new StringBuffer("Yellow");
		color.append(" ");
		color.append(" is ");
		color.append(" nice ");
		color.append(" cool ");
		color.append(" color ");
		System.out.println(color);
	}

	static void UC1() {

		char[] name = new char[6];
		name[0] = 'R';
		name[1] = 'i';
		name[2] = 't';
		name[3] = 'e';
		name[4] = 's';
		name[5] = 'h';

		System.out.println(name);

		String color = new String("Yellow");
		System.out.println(color);
		System.out.println(color.hashCode());
		
		color = color + " Color";
		
		System.out.println(color);
		System.out.println(color.hashCode());
	}
	
}