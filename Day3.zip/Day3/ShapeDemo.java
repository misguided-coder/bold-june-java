class ShapeDemo {
	public static void main(String[] args) {
		//UC1();
		UC2();
		System.out.println("Done!!");
	}

	static void UC2() {

		Shape shape1 = new Square();
		Shape shape2 = new Circle();		

		shape1.info();
		shape1.draw();

		shape2.info();
		shape2.draw();
	} 


	static void UC1() {

		Square square = new Square();
		Circle circle = new Circle();		

		square.info();
		square.draw();

		circle.info();
		circle.draw();
	}
 
}