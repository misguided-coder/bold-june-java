class TypeCastDemo {
	public static void main(String[] args) {

		int x = 100;
		long y = x; //implicit type casting

		System.out.println(x);
		System.out.println(y);

		long i = 56900899700L;
		int j = (int) i; //explicit type casting

		System.out.println(i);
		System.out.println(j);

	}	
}