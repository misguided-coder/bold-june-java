class OperatorDemo {
	public static void main(String[] args) {

		int pages = 680; 

		System.out.println(pages);
		System.out.println(++pages);
		System.out.println(pages);
	}	
}