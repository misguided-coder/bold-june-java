class DataTypeDemo {
	public static void main(String[] args) {

		//memory size 8 bits = 1 byte 
		byte age = 15; 
		System.out.println(age);

		//memory size 16 bits = 2 bytes 
		short length = 50; //metres
		System.out.println(length);

		//memory size 32 bits = 4 bytes 
		int pages = 680; 
		System.out.println(pages);

		//memory size 64 bits = 8 bytes 
		long balance = 70000000L; 
		System.out.println(balance);

		//memory size 32 bits = 4 bytes 
		float amount = 450.20F; 
		System.out.println(amount);

		//memory size 64 bits = 8 bytes 
		double initialBalance = 2000000.90; 
		System.out.println(initialBalance);

		//memory size 16 bits = 2 bytes 
		char letter = 'Y'; 
		System.out.println(letter);

		//memory size 1 bit 
		boolean failed = true; 
		System.out.println(failed);

	}	
}