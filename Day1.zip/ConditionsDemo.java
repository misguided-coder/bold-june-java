class ConditionsDemo {

	public static void main(String[] args) {
		//UC1();
		//UC2();
		//UC3();
		//UC4();
		//UC5();
		//UC6();
		UC7();

	}	

	static void UC7() {

		boolean status = true;
		int age = 24;

		//String result = status == true ? "I passed" : "I failed";
		//String result = status ? "I passed" : "I failed";
		//System.out.println(result);
		//System.out.println(status ? "I passed" : "I failed");
		System.out.println(age > 20 ? "You are old" : "You are young");
	}


	static void UC6() {

		boolean status = true;
		String result = "";

		//if(status == true) {
		if(status) {
			result = "I passed my exams"; 
		} else {
			result = "I could not pass my exams"; 
		}

		System.out.println(result);

	}





	static void UC5() {

		String color = "Red";
		
		switch(color) {
			case "Red" :
				System.out.println("Red is sun color.");
				break;	
			case "Green" :
				System.out.println("Green is always green.");
				break;	
			case "Blue" :
				System.out.println("Blue is cool.");
				break;	
			default :
				System.out.println("All colors are beautiful.");
		}

		System.out.println("Finish Line!!!!!");

	}



	static void UC4() {

		int age = 40;
		long amount = 500000L;
		
		if(age < 20) {
			System.out.println("You are young!!!!");
			if(amount > 200000L) {
				System.out.println("You are rich!!!!");
			}
		} else {
			System.out.println("You are old!!!!");
			if(amount < 200000L) {
				System.out.println("You are poor!!!!");
			} else if(amount < 400000L) {
				System.out.println("You are rich!!!!");
			} else if(amount < 600000L) {
				System.out.println("You are very rich!!!!");
			} else {
				System.out.println("You are bill gates!!!!");
			}
		}
	}



	static void UC3() {

		int age = 10;
		long amount = 500000L;
		
		if(age < 20) {
			System.out.println("You are young!!!!");
			if(amount > 200000L) {
				System.out.println("You are rich!!!!");
			}
		} else {
			System.out.println("You are old!!!!");
			System.out.println("You are poor!!!!");
		}
	}

	static void UC2() {

		int age = 50;
		long amount = 500000L;
		
		if(age < 20 && amount > 200000L) {
			System.out.println("You are young!!!!");
			System.out.println("You are rich!!!!");
		} else {
			System.out.println("You are old!!!!");
			System.out.println("You are poor!!!!");
		}
	}

	static void UC1() {

		int age = 10;
		
		if(age > 10) {
			System.out.println("You are young!!!!");
		} else {
			System.out.println("You are old!!!!");
		}
	}
}