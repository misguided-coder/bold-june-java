class ArraysDemo {
	
	static int size;

	public static void main(String[] args) {

		size = Integer.parseInt(args[0]);

		//UC1();
		//UC2();
		//UC3();
		//UC4();
		//UC5();
		//UC6();
		//UC7();
		//UC8();
		//UC9();
		//UC10();
		//UC11();
		UC12();
	}	


	static void UC12() {

		String[] colors1 = {"Red","Green","Blue","Yellow"};
		String[] colors2 = {"White","Orange","Pink","Black","Tomato"};
		
		System.arraycopy(colors1,2,colors2,1,2);

		for(String color : colors2) {
			System.out.println(color);
		}
	}

	static void UC11() {

		int[] numbers = {45,65,23,11,33,44,87,65,34,21,12,43,54,76,98,56}; 

		System.out.println(numbers[4]);
		
		numbers[4] = 1000;

		System.out.println(numbers[4]);
	
	}

	static void UC10() {

		int[][] numbers = new int[5][10];
			
		System.out.println(numbers.length);
		System.out.println(numbers[2].length);
	}


	static void UC9() {

		int[][] numbers = new int[5][10];
			
		for(int rowIndex = 0; rowIndex < 5; rowIndex++) {
			for(int colIndex = 0; colIndex < 10; colIndex++) {
				//numbers[rowIndex][colIndex] = 100 + rowIndex + colIndex;
				numbers[rowIndex][colIndex] = (int) (Math.random() * 5000);
			}		
		}		
		
		for(int rowIndex = 0; rowIndex < 5; rowIndex++) {
			for(int colIndex = 0; colIndex < 10; colIndex++) {
				System.out.print(numbers[rowIndex][colIndex]);
				System.out.print("   ");
			}
			System.out.println();
		}	
	}

	static void UC8() {

		int[][] numbers = new int[2][6];
					
		numbers[0][0] = 11;
		numbers[0][1] = 12;
		numbers[0][2] = 13;
		numbers[0][3] = 14;
		numbers[0][4] = 15;
		numbers[0][5] = 16;
 
		numbers[1][0] = 21;
		numbers[1][1] = 22;
		numbers[1][2] = 23;
		numbers[1][3] = 24;
		numbers[1][4] = 25;
		numbers[1][5] = 26;
		
		System.out.println(numbers[0][3]);
	}
	
	static void UC7() {

		int[] numbers = new int[size];

		for(int idx = 0; idx < numbers.length; idx++ ) {
			numbers[idx] = 1000+idx;
		}

		for(int value : numbers) {
			System.out.println(value);
		}
	}

	static void UC6() {

		int[] numbers = new int[20000];

		for(int idx = 0; idx < numbers.length; idx++ ) {
			numbers[idx] = 1000+idx;
		}

		for(int value : numbers) {
			System.out.println(value);
		}
	}

	static void UC5() {

		int[] numbers = {12,10,40,50,45,65,23,11,33,44,87,65,34,21,12,43,54,76,98,56}; 

		for(int value : numbers) {
			System.out.println(value*value);
		}
	}

	static void UC4() {

		int[] numbers = {12,10,40,50,45,65,23,11,33,44,87,65,34,21,12,43,54,76,98,56}; 

		for(int idx = 0; idx < numbers.length; idx++ ) {
			System.out.println(numbers[idx]);
		}
	}

	static void UC3() {

		//array declaration & initialization & population
		//int[] numbers = new int[]{45,65,23,11,33,44,87,65,34,21,12,43,54,76,98,56}; 
		int[] numbers = {45,65,23,11,33,44,87,65,34,21,12,43,54,76,98,56}; 

		System.out.println(numbers);
		System.out.println(numbers.length);
	
		System.out.println(numbers[0]);
		System.out.println(numbers[4]);
		System.out.println(numbers[9]);
	}

	static void UC2() {

		//array declaration & initialization
		int[] numbers = new int[10]; 

		//array population
		numbers[0] = 100;
		numbers[1] = 200;
		numbers[2] = 300;
		numbers[3] = 400;
		numbers[4] = 500;
		numbers[5] = 600;
		numbers[6] = 700;
		numbers[7] = 800;
		numbers[8] = 900;
		numbers[9] = 1000;
			
		System.out.println(numbers);
		System.out.println(numbers.length);
	
		System.out.println(numbers[0]);
		System.out.println(numbers[4]);
		System.out.println(numbers[9]);
	}

	static void UC1() {
		
		//array declaration
		int[] numbers;		
	
		//array initialization
		numbers = new int[10]; 

		//array population
		numbers[0] = 100;
		numbers[1] = 200;
		numbers[2] = 300;
		numbers[3] = 400;
		numbers[4] = 500;
		numbers[5] = 600;
		numbers[6] = 700;
		numbers[7] = 800;
		numbers[8] = 900;
		numbers[9] = 1000;

	
		System.out.println(numbers);
		System.out.println(numbers.length);
	
		System.out.println(numbers[0]);
		System.out.println(numbers[4]);
		System.out.println(numbers[9]);

	}
}