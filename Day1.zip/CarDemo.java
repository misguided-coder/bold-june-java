class CarDemo {
	public static void main(String[] args) {
	
		Car car = new Car();	
	
		System.out.println(car);
		System.out.println(car.vin);
		System.out.println(car.model);
		System.out.println(car.make);
		System.out.println(car.price);
		System.out.println(car.color);
	
		car.start();
		car.accelerate();
		car.accelerate();
		car.accelerate();
		car.accelerate();
		car.applyBrake();
		car.applyBrake();
		car.stop();

		System.out.println("Done!!");
	}	
}