class LoopsDemo {

	public static void main(String[] args) {
		//UC1();
		//UC2();
		//UC3();
		//UC4();
		UC5();
	}	

	static void UC5() {

		for(int i=1; i <= 100; i++) {

			if(i%5 == 0){
				continue;		
			}
			System.out.println("I : "+i);
		}
	}


	static void UC4() {

		for(int i=1; i <= 10; i++) {
			System.out.println("I : "+i);
			for(int j=1; j <= 5; j++) {
				System.out.println("J : "+j);
			}	
		}
	}

	static void UC3() {

		for(int idx=0; idx < 10; idx++) {
			System.out.println("India is great!!!!");
		}
	}

	static void UC2() {

		int idx = 1000;	
		
		do {
			System.out.println("India is great!!!!");
			idx++;	
		} while(idx < 10);
		
		System.out.println("Finish Line!!!!");
	}

	static void UC1() {
		
		int idx = 0;	
		
		while(idx < 10) {
			System.out.println("India is great!!!!");
			//idx = idx + 1;
			idx++;	
		}
		
		System.out.println("Finish Line!!!!");
	}
}