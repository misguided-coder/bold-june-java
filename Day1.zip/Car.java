class Car {
	
	int vin;
	String model;
	String make;
	double price;
	String color;

	void start() {
		System.out.println("Car Engine started!!");	
	}

	void stop() {
		System.out.println("Car Engine stopped!!");	
	}

	void applyBrake() {
		System.out.println("Car is slowing down!!");	
	}

	void accelerate() {
		System.out.println("Car is speeding up!!");	
	}
}