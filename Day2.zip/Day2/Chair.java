class Chair extends Furniture {
	
	String material;	
	int legs;
	int hands;

	Chair() {
		this.material = "Gold";
		this.hands = 2;
		this.legs = 4;
		//super(1000,"Iron",1500.00);
		System.out.println("Inside Chair() cunstructor!!!!");
	}		

	Chair(int id,String material,double price) {
		super(id,material,price);
		System.out.println("Inside Chair(int id,String material,double price) cunstructor!!!!");
	}

	//partial overriding
	void info() {
		super.info(); 
		System.out.printf("Hands : %s%n",this.hands);
		System.out.printf("Legs : %s%n",this.legs);
	}

	//full overriding/replacement
	void make() {
		System.out.printf("Chair is made of %s%n",this.material);
	}

	void sell() {
		System.out.println("Chair is sold to Bill Gates");
	}

}