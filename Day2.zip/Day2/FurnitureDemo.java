class FurnitureDemo {
	public static void main(String[] args) {

		//UC1();	
		//UC2();	
		//UC3();	
		//UC4();	
		//UC5();	
		//UC6();	
		//UC7();	
		UC8();	
	
		System.out.println("Done!!");
	}

	//inheritence type casting rules
	static void UC8() {

		//Furniture furniture = new Furniture();
		//Chair chair = new Chair();
		//Desk desk = new Desk();
		
		//Chair chair = new Furniture(); //will not compile
	
		Furniture furniture = new Chair(); //will work
		furniture.make();
		furniture.paint();

		System.out.println(furniture);

		Chair chair = (Chair) furniture;
		chair.sell();
		
		furniture = new Desk(); //will work
		furniture.make();
		System.out.println(furniture);
		
		//Furniture furniture = null;

		//System.out.println(furniture);
		//System.out.println(chair);
		//System.out.println(desk);


	}	


	//accessing sub class extra properties
	static void UC7() {

		Furniture furniture = new Furniture();
		Chair chair = new Chair();

	
		furniture.info();
		chair.info();

		/*System.out.println(furniture.id);
		System.out.println(furniture.material);
		System.out.println(furniture.price);
	
		System.out.println(chair.id);
		System.out.println(chair.material);
		System.out.println(chair.price);
		System.out.println(chair.legs);
		System.out.println(chair.hands);*/

	}	



	//accessing sub class overridden method 
	static void UC6() {

		Furniture furniture = new Furniture();
		Chair chair = new Chair();
		Desk desk = new Desk();

		furniture.make();
		chair.make();
		desk.make();
	}	


	//accessing sub class overridden property 
	static void UC5() {

		Furniture furniture = new Furniture();
		Chair chair = new Chair();
	
		System.out.println(furniture.id);
		System.out.println(furniture.material);
		
		System.out.println(chair.id);
		System.out.println(chair.material);
	}	



	//calling super class full constructor from sub class parameterized constructor 
	static void UC4() {

		Furniture furniture = new Furniture(10,"Plastic",20000.00);
		furniture.info();
		
		Chair chair = new Chair(20,"Wood",4000.00);
		chair.info();
		
		Desk desk = new Desk(30,"Silver",6000.00);
		desk.info();
	}	


	//calling super class full constructor from sub class default constructor 
	static void UC3() {

		Furniture furniture = new Furniture(10,"Plastic",20000.00);

		System.out.println(furniture.id);
		System.out.println(furniture.material);
		System.out.println(furniture.price);
	
		Chair chair = new Chair();
		System.out.println(chair.id);
		System.out.println(chair.material);
		System.out.println(chair.price);

		Desk desk = new Desk();
		System.out.println(desk.id);
		System.out.println(desk.material);
		System.out.println(desk.price);
	}	

	//functionalities inheritence
	static void UC2() {

		Furniture furniture = new Furniture();
		Chair chair = new Chair();
		Desk desk = new Desk();
		
		furniture.make();
		furniture.paint();

		chair.make();
		chair.paint();

		desk.make();
		desk.paint();
	}	


	//data member inheritence
	static void UC1() {

		Furniture furniture = new Furniture();
		System.out.println(furniture.id);
		System.out.println(furniture.material);
		System.out.println(furniture.price);
	
		Chair chair = new Chair();
		System.out.println(chair.id);
		System.out.println(chair.material);
		System.out.println(chair.price);

		Desk desk = new Desk();
		System.out.println(desk.id);
		System.out.println(desk.material);
		System.out.println(desk.price);
	}	
}