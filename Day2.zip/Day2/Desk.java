class Desk extends Furniture {

	Desk() {
		super(2000,"Iron",3500.00);
		System.out.println("Inside Desk() cunstructor!!!!");
	}	

	Desk(int id,String material,double price) {
		super(id,material,price);
		System.out.println("Inside Desk(int id,String material,double price) cunstructor!!!!");
	}

	void make() {
		System.out.printf("Desk is made of %s%n",this.material);
	}


}