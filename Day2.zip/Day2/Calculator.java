class Calculator {
	
	void sum(int arg1,int arg2) {
		System.out.println("Inside sum(int arg1,int arg2)!!!!");	
		System.out.printf("Result : %s%n",arg1+arg2);	
	}	

	void sum(int arg1,int arg2,int arg3) {
		System.out.println("Inside sum(int arg1,int arg2,int arg3)!!!!");	
		System.out.printf("Result : %s%n",arg1+arg2+arg3);	
	}	

	/*void sum(int arg1,long arg2) {
		System.out.println("Inside sum(int arg1,long arg2)!!!!");	
		System.out.printf("Result : %s%n",arg1+arg2);	
	}	

	void sum(long arg1,int arg2) {
		System.out.println("Inside sum(long arg1,int arg2)!!!!");	
		System.out.printf("Result : %s%n",arg1+arg2);	
	}	

	void sum(float arg1,int arg2) {
		System.out.println("Inside sum(float arg1,int arg2)!!!!");	
		System.out.printf("Result : %s%n",arg1+arg2);	
	}	

	void sum(float arg1,float arg2) {
		System.out.println("Inside sum(float arg1,float arg2)!!!!");	
		System.out.printf("Result : %s%n",arg1+arg2);	
	}	

	void sum(double arg1,double arg2) {
		System.out.println("Inside sum(double arg1,double arg2)!!!!");	
		System.out.printf("Result : %s%n",arg1+arg2);	
	}*/

	//can accept any number of int arguments
	//Java 5
	void sum(int... args) {
		System.out.println("Inside sum(int... args)!!!!");	
		System.out.printf("Length : %s%n",args.length);	
		int rs = 0;
		for(int value : args) {
			rs += value;
		}
		System.out.printf("SUM : %s%n",rs);	
	}	

	
}