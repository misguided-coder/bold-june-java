class CarDemo {
	public static void main(String[] args) {

		//UC1();	
		//UC2();	
		UC3();	
		System.out.println("Done!!");
	}

	static void UC3() {

		Car car1 = new Car(1,"Q7","Audi",5600000.00,"Red",120);	
		Car car2 = new Car(2,"X6","BMW",2600000.00,"Black",200);	
		Car car3 = new Car();	
		Car car4 = new Car(4,"X1","BMW","Black",140);	
		Car car5 = new Car(5,"CLA","Merc",180);	

		car1.info();
		car2.info();
		car3.info();
		car4.info();
		car5.info();
	
		car1.start();
		car2.start();

		car1.accelerate();
		car2.accelerate();
	}	


	static void UC2() {

		Car car1 = new Car();	
		Car car2 = new Car();	
		Car car3 = new Car();	
		Car car4 = new Car();	
		Car car5 = new Car();	
		
		car1.vin =  1000;
		car1.model =  "Q5";
		car1.make =  "Audi";
		car1.price =  4500000.00;
		car1.color =  "Black";
		car1.speed =  80;

		car2.vin =  2000;
		car2.model =  "A1";
		car2.make =  "Audi";
		car2.price =  2500000.00;
		car2.color =  "Yellow";
		car2.speed =  100;
		
		System.out.println("VIN : "+car1.vin);
		System.out.println("Model : "+car1.model);
		System.out.println("Make : "+car1.make);
		System.out.println("Price : "+car1.price);
		System.out.println("Color : "+car1.color);
		System.out.println("Speed : "+car1.speed);
	
		System.out.println("VIN : "+car2.vin);
		System.out.println("Model : "+car2.model);
		System.out.println("Make : "+car2.make);
		System.out.println("Price : "+car2.price);
		System.out.println("Color : "+car2.color);
		System.out.println("Speed : "+car2.speed);
			

		car1.start();
		car2.start();

		car1.accelerate();
		car2.accelerate();
	}	


	static void UC1() {

		Car car = new Car();	
		
		car.vin =  1000;
		car.model =  "Q5";
		car.make =  "Audi";
		car.price =  4500000.00;
		car.color =  "Black";
		car.speed =  80;
		
		System.out.println(car);

		System.out.println("VIN : "+car.vin);
		System.out.println("Model : "+car.model);
		System.out.println("Make : "+car.make);
		System.out.println("Price : "+car.price);
		System.out.println("Color : "+car.color);
		System.out.println("Speed : "+car.speed);
	
		car.start();
		car.accelerate();
		car.accelerate();
		car.accelerate();
		car.accelerate();
		car.applyBrake();
		car.applyBrake();
		car.stop();

		System.out.println("Speed : "+car.speed);

	}	
}