class Car {
	
	int vin;
	String model;
	String make;
	double price;
	String color;
	int speed;

	Car() {
		this(100,"XE","Jaguar",Math.random()*1000000,"Yellow",200);
		System.out.println("Inside Car() constructor!!!!");
	}

	Car(int vin,String model,String make,double price,String color,int speed) {
		System.out.println("Inside Car(int vin,String model,String make,double price,String color,int speed) constructor!!!!");
		this.vin = vin; 
		this.model = model; 
		this.make = make; 
		this.price = price; 
		this.color = color;
		this.speed = speed; 
	}

	Car(int vin,String model,String make,String color,int speed) {
		this(vin,model,make,Math.random()*5000000,color,speed);
		System.out.println("Inside Car(int vin,String model,String make,String color,int speed) constructor!!!!");
	}

	Car(int vin,String model,String make,int speed) {
		this(vin,model,make,Math.random()*5000000,"White",speed);
		System.out.println("Inside Car(int vin,String model,String make,int speed) constructor!!!!");
	}

	void info() {
		System.out.printf("VIN : %s%n",this.vin);
		System.out.printf("Model : %s%n",this.model);
		System.out.printf("Make : %s%n",this.make);
		System.out.printf("Price : %s%n",this.price);
		System.out.printf("Color : %s%n",this.color);
		System.out.printf("Speed : %s%n",this.speed);
		System.out.println("============================");
	}

	void start() {
		System.out.printf("Car %s %s started!!%n",this.make,this.model);	
	}

	void stop() {
		System.out.println("Car "+this.make+" "+this.model+" stopped!!");	
	}

	void applyBrake() {
		this.speed = this.speed - 10;
		System.out.println("Car is slowing down!!");	
	}

	void accelerate() {
		this.speed = this.speed + 10;
		System.out.println("Car is speeding up and running at the speed of "+this.speed+" miles per hour!!");	
	}
}