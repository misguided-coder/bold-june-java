class EmployeeDemo {
	public static void main(String[] args) {

		//UC1();	
		UC2();	
		//UC3();	
		System.out.println("Done!!");
	}

	static void UC3() {

	}	


	static void UC2() {

		Employee e1 = new Employee();
	
		System.out.println(e1.id);
		System.out.println(e1.name);
		System.out.println(e1.getName());
	
		//e1.name = "Jaggu";
		e1.setName("Ram");
		System.out.println(e1.getName());
		System.out.println(e1.getSalary());
		System.out.println(e1.desig);
		System.out.println(e1.dept);

	}	


	static void UC1() {
		
		Employee e1 = new Employee();
	
		System.out.println(e1.id);
		System.out.println(e1.name);

		//salary data is hidden so can not be accessed
		//System.out.println(e1.salary); //code will not compile
		System.out.println(e1.desig);
		System.out.println(e1.dept);

		//e1.salary = 100; //code will not compile

		//System.out.println(e1.salary); //code will not compile
	}	
}