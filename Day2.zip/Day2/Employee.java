class Employee {
	
	int id;
	String name;
	private long salary; //salary is immutable and hidden
	String desig;
	String dept;

	Employee() {
		this.id = 100;
		this.name = "Pintu";
		this.salary = 120000L;
		this.desig = "SE";
		this.dept = "SW";
	}	

	String getName() {
		return this.name;
	}

	void setName(String name) {
		if(name.length() < 5) {
			return;
		}
		this.name = name;
	}

	long getSalary() {
		return this.salary;
	}

}