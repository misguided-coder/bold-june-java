class CalculatorDemo {
	public static void main(String[] args) {
		//UC1();
		UC2();
		System.out.println("Done!!");
	}

	static void UC2() {

		Calculator calculator = new Calculator();		
		
		calculator.sum(10,2);
		calculator.sum(10,2,4);
		calculator.sum(23,54,10,2,4);
		calculator.sum(18,10,2,4);
		calculator.sum(3,6,12,56,32,45,10,2,4);
	} 


	static void UC1() {
		Calculator calculator = new Calculator();		
		
		/*calculator.sum(10,2);
		calculator.sum(10,2L);
		calculator.sum(10L,2);
		calculator.sum(10,2,4);

		calculator.sum(50.00F,10);
		calculator.sum(50.00,10);
		calculator.sum(50.00F,10.00F);
		calculator.sum(50.00,10.00);*/
	} 

}