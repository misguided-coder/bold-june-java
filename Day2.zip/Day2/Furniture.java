class Furniture {
	
	int id;
	String material;
	double price;	

	Furniture() {
		System.out.println("Inside Furniture() cunstructor!!!!");
		this.id = 1;
		this.material = "Wood";
		this.price = 1200.00;
	}

	Furniture(int id,String material,double price) {
		System.out.println("Inside Furniture(int id,String material,double price) cunstructor!!!!");
		this.id = id;
		this.material = material;
		this.price = price;
	}

	void info() {
		System.out.printf("ID : %s%n",this.id);
		System.out.printf("Material : %s%n",this.material);
		System.out.printf("Price : %s%n",this.price);
	}

	void make() {
		System.out.println("Furniture is ready!!!!");
	}

	void paint() {
		System.out.println("Furniture painted with hand brush!!!!");
	}
}